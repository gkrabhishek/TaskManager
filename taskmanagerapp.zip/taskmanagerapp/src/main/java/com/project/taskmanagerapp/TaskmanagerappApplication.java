package com.project.taskmanagerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskmanagerappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskmanagerappApplication.class, args);
	}

}
